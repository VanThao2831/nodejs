package profile.bean;

public class Profile {
	private String usrName;
	private String passWord;
	private String name;
	private String introduce;
	private int numbExp;
	private String titleExp;
	private String contextExp;
	
	public String getUsrName() {
		return usrName;
	}
	public void setUsrName(String usrName) {
		this.usrName = usrName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public int getNumbExp() {
		return numbExp;
	}
	public void setNumbExp(int numbExp) {
		this.numbExp = numbExp;
	}
	public String getTitleExp() {
		return titleExp;
	}
	public void setTitleExp(String titleExp) {
		this.titleExp = titleExp;
	}
	public String getContextExp() {
		return contextExp;
	}
	public void setContextExp(String contextExp) {
		this.contextExp = contextExp;
	}
	
	
	
}
