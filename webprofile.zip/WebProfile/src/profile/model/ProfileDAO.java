package profile.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import profile.bean.Profile;
import profile.connect.ConnectDBMySQL;

public class ProfileDAO{
	Connection connDB;
	private Profile profile;
	
	private List<Profile> listProfile;
	
	
	public void setListProfile(List<Profile> listProfile) {
		this.listProfile = listProfile;
	}


	public List<Profile> getInfoProfle() throws ClassNotFoundException, SQLException{
		String sql = "select * from profile";
		connDB = ConnectDBMySQL.getMySQLConnection();
		listProfile = new ArrayList<Profile>();
		profile = new Profile();
		PreparedStatement ps = connDB.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			
			profile.setUsrName(rs.getString("userName"));
			profile.setPassWord(rs.getString("passWord"));
			profile.setName(rs.getString("name"));
			profile.setIntroduce(rs.getString("introduce"));
			profile.setNumbExp(rs.getInt("numbExperience"));
			profile.setTitleExp(rs.getString("titleExperience"));
			profile.setContextExp(rs.getString("contextExperience"));

			listProfile.add(profile);
		}
		rs.close();
		ps.close();
		ConnectDBMySQL.disconnect();
		return listProfile;
	}

	public void insertProfile(Profile profile) throws ClassNotFoundException, SQLException{
		String sql = "insert into profile(userName, passWord, name, introduce, numbExperience, titleExperience, contextExperience) value (?,?,?,?,?,?,?) ";
		connDB = ConnectDBMySQL.getMySQLConnection();
		PreparedStatement ps = connDB.prepareStatement(sql);
		ps.setString(1, profile.getUsrName());
		ps.setString(2, profile.getPassWord());
		ps.setString(3, profile.getName());
		ps.setString(4, profile.getIntroduce());
		ps.setInt(5, profile.getNumbExp());
		ps.setString(6, profile.getTitleExp());
		ps.setString(7, profile.getContextExp());
		ps.executeUpdate();
		ps.close();
		ConnectDBMySQL.disconnect();
		
	}


	public List<Profile> getAccountLogin(String inputUserName) throws ClassNotFoundException, SQLException {
		String sql = "select * from profile where userName = ?";
		connDB = ConnectDBMySQL.getMySQLConnection();
		List<Profile> listAccount = new ArrayList<Profile>();
		Profile profile = new Profile();
		PreparedStatement ps = connDB.prepareStatement(sql);
		ps.setString(1, inputUserName);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			profile.setUsrName(rs.getString("userName"));
			profile.setPassWord(rs.getString("passWord"));
			listAccount.add(profile);
		}
		rs.close();
		ps.close();
		ConnectDBMySQL.disconnect();
		return listAccount;
	}


	
	
	/*test*/
	public static void main(String args[]) throws ClassNotFoundException, SQLException{
		ProfileDAO proDao = new ProfileDAO();
		List<Profile> listAccout = proDao.getAccountLogin("thaonv");
		for(int i=0; i < listAccout.size(); i++){
			System.out.println(listAccout.get(i).getUsrName());
		}

	}
	
}
