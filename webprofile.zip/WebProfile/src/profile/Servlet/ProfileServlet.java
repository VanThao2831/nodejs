package profile.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import profile.bean.Profile;
import profile.model.ProfileDAO;

/**
 * Servlet implementation class ProfileServlet
 */
@WebServlet(urlPatterns={"/ProfileServlet"})
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private ProfileDAO profileDao;
    private List<Profile> listProfile = new ArrayList<Profile>();
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProfileServlet() {
        super();
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		profileDao = new ProfileDAO();
		String inputUserName = request.getParameter("inputUserName");
		String inputPassWord = request.getParameter("inputPassword");
		String inputName = request.getParameter("inputName");
		String inputIntroduce = request.getParameter("inputIntroduce");
		String inputNumbExp = request.getParameter("inputNumbExp");
		String inputTileExp = request.getParameter("inputTileExp");
		String inputContentExp = request.getParameter("inputContentExp");
		String action = request.getParameter("action");

		
		
		
		if ("Insert".equals(action)) {
			
			if(inputUserName != null || inputPassWord != null){
				Profile profile = new Profile();
				profile.setUsrName(inputUserName);
				profile.setPassWord(inputPassWord);
				profile.setName(inputName);
				profile.setIntroduce(inputIntroduce);
				profile.setNumbExp(Integer.parseInt(inputNumbExp));
				profile.setTitleExp(inputTileExp);
				profile.setContextExp(inputContentExp);
				
				try {
					
					profileDao.insertProfile(profile);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		} 
		try {
			listProfile = profileDao.getInfoProfle();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("listProfile", listProfile);
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
		
	}

}
