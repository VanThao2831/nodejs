package profile.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDBMySQL {
	private static Connection conn;
	public static Connection getMySQLConnection()
	        throws ClassNotFoundException, SQLException {
	    String hostName = "localhost";
	    String dbName = "myprofile";
	    String userName = "ThaoNV";
	    String password = "CaoThu@#$2831";
	    return getMySQLConnection(hostName, dbName, userName, password);
	}
	
	public static Connection getMySQLConnection(String hostName, String dbName,
	        String userName, String password) throws SQLException,
	        ClassNotFoundException {
	   if(conn == null || conn.isClosed()){
		   Class.forName("com.mysql.jdbc.Driver");
		   String connectionURL = "jdbc:mysql://" + hostName + ":3306/" + dbName;
		   conn = DriverManager.getConnection(connectionURL, userName, password);
	   }
	    
	   return conn;
	}
	
	public static void disconnect() throws SQLException {
        if (conn != null && !conn.isClosed()) {
        	conn.close();
        }
    }
	
	/*public static void main(String args[]) throws ClassNotFoundException, SQLException{
		ConnectDBMySQL connNew = new ConnectDBMySQL();
		String test = (String) connNew.getMySQLConnection().toString();
	}*/
}
